 
function onDeviceReady() {
    navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
    destinationType: Camera.DestinationType.DATA_URL
});

}

function onSuccess(imageData) {
document.getElementById('status').value='OK';

    var image = document.getElementById('myImage');
    image.src = "data:image/jpeg;base64," + imageData;
}

function onFail(message) {
    document.getElementById('status').value=
'Failed because: ' + message;
}

            



$(document).bind('deviceready',function(){
	
        


            document.getElementById('status').value='Ready'; 

            
            $("#recordBtn").click(function(){
                onDeviceReady();                  
            });




})

