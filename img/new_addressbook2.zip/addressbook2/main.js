 
function onDeviceReady() {
var options = new ContactFindOptions();
options.filter="Bob";
options.multiple=true; 
var fields = ["displayName", "name"];
navigator.contacts.find(fields, onSuccess, onError, options);
}

function onSuccess(contacts) {
document.getElementById('status').value='OK';

    
}

function onError(contactError) {
    document.getElementById('status').value=
'Failed because: ' + contactError;
}

            



$(document).bind('deviceready',function(){
	
        


            document.getElementById('status').value='Ready'; 

            
            $("#recordBtn").click(function(){
                onDeviceReady();                  
            });




})

